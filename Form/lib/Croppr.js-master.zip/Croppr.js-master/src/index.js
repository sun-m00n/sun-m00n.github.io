import './polyfills';
import Croppr from './croppr.js';
export default Croppr;