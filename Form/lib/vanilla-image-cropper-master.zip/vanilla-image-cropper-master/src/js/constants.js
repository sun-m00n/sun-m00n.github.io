export const STATES = {
    OFFLINE : 0,
    LOADING : 1,
    READY : 2,
};

export const MODES = {
    SQUARE : 'square',
    CIRCULAR : 'circular',
};
